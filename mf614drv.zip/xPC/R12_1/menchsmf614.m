function [SampleTime, SampleOffset] = menchsmf614 (flag, boardType, Channels, Range, Sample, Slot)

% MENCHSMF614 - InitFcn and Mask Initialization for Humusoft MF614 encoder section

% Copyright (c) 2003 by Humusoft s.r.o.
% $Revision:  $ $Date:  $

% Initialize Data Values
persistent pool;

if flag == 0
  pool = [];
  return;
end

MAX_CHANNEL=4;

switch boardType
  case 1
    chnDisplay='disp(''MF614\nHumusoft\n';
    description='MF614';
  case 2
    chnDisplay='disp(''AD612\nHumusoft\n';
    description='AD612';
end

% Get Length Channel Vector
chnLength = length(Channels);

% Label Output Ports

% Compose MaskDisplay String
chnDisplay=[chnDisplay,'Encoder Input'');'];
for i = 1:chnLength
  chnDisplay = strcat(chnDisplay,'port_label(''output'', ');
  chnDisplay = strcat(chnDisplay,num2str (i));
  chnDisplay = strcat(chnDisplay,' , ''');
  chnDisplay = strcat(chnDisplay, num2str (Channels(1,i)));
  chnDisplay = strcat(chnDisplay, ''') ');
end

% Set MaskDisplay String
set_param(gcb,'MaskDisplay',chnDisplay);

% Check Parameters
for i=1:chnLength
   if (Channels(i)<1 | Channels(i)>MAX_CHANNEL)
      error(['The number of channels must be in the range 1..',num2str(MAX_CHANNEL)]);
   end
end

rangeLength =  length(Range);
if rangeLength ~= chnLength
  error ('Length of the filter and channel vectors must be equal');
end

for i = 1:rangeLength
  if (Range(i)>25000000 | Range(i)<10000)
    error ('Invalid Filter frequency value: valid values are 10000 - 25000000');
  end
end

% Check sample time

sampleLength = length (Sample);

if (sampleLength > 2)
  error ('Sample length vector cannot exceed two elements');
end

if (sampleLength == 2)
  SampleTime = Sample(1);
  SampleOffset = Sample(2);
else
  SampleTime = Sample(1);
  SampleOffset = 0;
end

% Check For Multipule instances using the same channel

boardtype=['btype',num2str(boardType)];
if Slot<0
  boardref=['ref','a'];
else
  boardref=['ref',num2str(Slot)];
end
if ~isfield(pool,boardtype)
  eval(['pool.',boardtype,'=[];']);
end
level1=getfield(pool,boardtype);
if ~isfield(level1,boardref)
  eval(['level1.',boardref,'.chUsed=zeros(1,MAX_CHANNEL);']);
end
level2=getfield(level1,boardref);
for i = 1:length(Channels)
  channel=Channels(i);
  if channel<1 | channel > MAX_CHANNEL
    error(['Elements of the channel vector must be in between 1 and ',num2str(MAX_CHANNEL)]);
  end
  if level2.chUsed(channel)==1
    error(['Channel ',num2str(channel),' already in use']);
  end
  level2.chUsed(channel)=1;
end

level1=setfield(level1,boardref,level2);
pool=setfield(pool,boardtype,level1);

%% EOF menchsmf614.m
