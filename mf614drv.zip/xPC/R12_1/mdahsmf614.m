function [SampleTime, SampleOffset] = mdahsmf614 (flag, boardType, Channels, Range, Sample, Slot)

% MDAHSMF614 - InitFcn and Mask Initialization for Humusoft MF614 D/A section

% Copyright (c) 2003 by Humusoft s.r.o.
% $Revision:  $ $Date:  $

% Initialize Data Values
persistent pool;

if flag == 0
  pool = [];
  return;
end

MAX_CHANNEL=4;

switch boardType
  case 1
    chnDisplay='disp(''MF614\nHumusoft\n';
    description='MF614';
  case 2
    chnDisplay='disp(''AD612\nHumusoft\n';
    description='AD612';
end

RangeElements = [-10];
RangeStr='-10';


% Get Length Channel Vector
chnLength = length(Channels);

% Label Input Ports

% Compose MaskDisplay String
chnDisplay=[chnDisplay,'Analog Output'');'];
for i = 1:chnLength
  chnDisplay = strcat(chnDisplay,'port_label(''input'', ');
  chnDisplay = strcat(chnDisplay,num2str (i));
  chnDisplay = strcat(chnDisplay,' , ''');
  chnDisplay = strcat(chnDisplay, num2str (Channels(1,i)));
  chnDisplay = strcat(chnDisplay, ''') ');
end

% Set MaskDisplay String
set_param(gcb,'MaskDisplay',chnDisplay);

% Check Parameters
for i=1:chnLength
   if (Channels(i)<1 | Channels(i)>MAX_CHANNEL)
      error(['The number of channels must be in the range 1..',num2str(MAX_CHANNEL)]);
   end
end


% Check sample time

sampleLength = length (Sample);

if (sampleLength > 2)
  error ('Sample length vector cannot exceed two elements');
end

if (sampleLength == 2)
  SampleTime = Sample(1);
  SampleOffset = Sample(2);
else
  SampleTime = Sample(1);
  SampleOffset = 0;
end

% Check For Multipule instances using the same channel

boardtype=['btype',num2str(boardType)];
if Slot<0
  boardref=['ref','a'];
else
  boardref=['ref',num2str(Slot)];
end
if ~isfield(pool,boardref)
  eval(['pool.',boardref,'.chUsed=zeros(1,MAX_CHANNEL);']);
end
level1=getfield(pool,boardref);
for i = 1:length(Channels)
  channel=Channels(i);
  if channel<1 | channel > MAX_CHANNEL
    error(['Elements of the channel vector must be in between 1 and ',num2str(MAX_CHANNEL)]);
  end
  if level1.chUsed(channel)==1
    error(['Channel ',num2str(channel),' already in use']);
  end
  level1.chUsed(channel)=1;
end

pool=setfield(pool,boardref,level1);

%% EOF mdahsmf614.m
