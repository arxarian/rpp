/* $Revision:  $ $Date:  $ */
/* adhsmf614.c - xPC Target, non-inlined S-function driver for A/D section of Humusoft MF614 board  */
/* Copyright (c) 2003 by Humusoft s.r.o. All Rights Reserved. */

#define 	S_FUNCTION_LEVEL 	2
#define 	S_FUNCTION_NAME 	adhsmf614

#include 	<stddef.h>
#include 	<stdlib.h>

#include 	"simstruc.h" 

#ifdef 		MATLAB_MEX_FILE
#include 	"mex.h"
#else
#include        <windows.h>
#include        "io_xpcimport.h"
#include        "pci_xpcimport.h"
#endif


/* Input Arguments */
#define NUM_PARAMS             (5)
#define SLOT_ARG               (ssGetSFcnParam(S,0))
#define DEV_ARG                (ssGetSFcnParam(S,1))
#define CHANNEL_ARG            (ssGetSFcnParam(S,2))
#define RANGE_ARG              (ssGetSFcnParam(S,3))
#define SAMPLE_TIME_PARAM      (ssGetSFcnParam(S,4))

/* Convert S Function Parameters to Varibles */

#define SLOT                   ((uint_T) mxGetPr(SLOT_ARG)[0])
#define SAMPLE_TIME            ((real_T) mxGetPr(SAMPLE_TIME_PARAM)[0])
#define SAMPLE_OFFSET          ((real_T) mxGetPr(SAMPLE_TIME_PARAM)[1])
#define SAMP_TIME_IND          (0)

#define NO_I_WORKS             (2)
#define BASE_ADDR_I_IND        (0)

#define NO_R_WORKS             (0)

static char_T msg[256];

#define rl32eInp_W(adr)      (rl32eInpB(adr)+(rl32eInpB((adr)+1)<<8))


/*====================*
 * S-function methods *
 *====================*/

static void mdlCheckParameters(SimStruct *S)
{
}

static void mdlInitializeSizes(SimStruct *S)
{
    uint_T i;

#ifndef MATLAB_MEX_FILE
#include "io_xpcimport.c"
#include "pci_xpcimport.c"
#endif


    ssSetNumSFcnParams(S, NUM_PARAMS);
    if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {
        mdlCheckParameters(S);
        if (ssGetErrorStatus(S) != NULL) {
            return;
        }
    } else {
        return; /* Parameter mismatch will be reported by Simulink */
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

	

    if (!ssSetNumInputPorts(S, 0)) return;

    if (!ssSetNumOutputPorts(S, mxGetNumberOfElements(CHANNEL_ARG))) return;

    for (i=0;i<mxGetNumberOfElements(CHANNEL_ARG);i++) {
        ssSetOutputPortWidth(S, i, 1);
    }

    ssSetNumSampleTimes(S, 1);
    ssSetNumRWork(S, NO_R_WORKS);
    ssSetNumIWork(S, NO_I_WORKS);
    ssSetNumPWork(S, 0);

    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    ssSetSFcnParamNotTunable(S,0);
    ssSetSFcnParamNotTunable(S,1);
    ssSetSFcnParamNotTunable(S,2);
    ssSetSFcnParamNotTunable(S,3);
    ssSetSFcnParamNotTunable(S,4);

    ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE | SS_OPTION_PLACE_ASAP);
	
}


 
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, SAMPLE_TIME);
    ssSetOffsetTime(S, 0, SAMPLE_OFFSET);
}

 

#define MDL_START
static void mdlStart(SimStruct *S)
{

#ifndef MATLAB_MEX_FILE


    uint_T i, channel;
    PCIDeviceInfo pciinfo;
    uint_T base_adc, base_status;
    char devName[20];
    int  devId;

    switch ((int_T)mxGetPr(DEV_ARG)[0]) {
        case 1:
            strcpy(devName,"Humusoft MF614");
            devId=0x0614;
            break;
        case 2:
            strcpy(devName,"Humusoft AD612");
            devId=0x0612;
            break;
         }

    if ((int_T)mxGetPr(SLOT_ARG)[0]<0) {
        // look for the PCI-Device
        if (rl32eGetPCIInfo(0x186C,(unsigned short)devId,&pciinfo)) {
            sprintf(msg,"%s: board not present", devName);
            ssSetErrorStatus(S,msg);
            return;
        }
    } else {
        int_T bus, slot;
        if (mxGetN(SLOT_ARG) == 1) {
            bus  = 0;
            slot = (int_T)mxGetPr(SLOT_ARG)[0];
        } else {
            bus = (int_T)mxGetPr(SLOT_ARG)[0];
            slot = (int_T)mxGetPr(SLOT_ARG)[1];
        }
        // look for the PCI-Device
        if (rl32eGetPCIInfoAtSlot(0x186C,(unsigned short)devId,(slot & 0xff) | ((bus & 0xff)<< 8),&pciinfo)) {
            sprintf(msg,"%s (bus %d, slot %d): board not present",devName, bus, slot );
            ssSetErrorStatus(S,msg);
            return;
        }
    }

    // show Device Information
    // rl32eShowPCIInfo(pciinfo);

    base_adc=pciinfo.BaseAddress[0];
    base_status=pciinfo.BaseAddress[2];

    ssSetIWorkValue(S, BASE_ADDR_I_IND, (int_T)base_adc);
    ssSetIWorkValue(S, BASE_ADDR_I_IND+1, (int_T)base_status);

    /* Check That The Hardware is functioning */

    rl32eInp_W((unsigned short)(base_adc));              /* dummy read from A/D */
    if (!(rl32eInpB((unsigned short)(base_status+0x10)) & 0x04)) { /* if data ready, error */
        sprintf(msg,"%s (%d): test A/D conversion failed", devName, SLOT);
        ssSetErrorStatus(S,msg);
        return;
    }

    rl32eOutpB((unsigned short)(base_adc),0x40);        /* try the conversion */
    for (i=0;i<0x10000;i++)
        if (!(rl32eInpB((unsigned short)(base_status+0x10)) & 0x04)) break;
    if (i==0x10000) {               /* if no conversion, error */
        sprintf(msg,"%s (%d): test A/D conversion failed", devName, SLOT);
        ssSetErrorStatus(S,msg);
        return;
    }

    rl32eInp_W((unsigned short)(base_adc));
    if (!(rl32eInpB((unsigned short)(base_status+0x10)) & 0x04)) { /* if data still ready, error */
        sprintf(msg,"%s (%d): test A/D conversion failed", devName, SLOT);
        ssSetErrorStatus(S,msg);
        return;
    }

#endif
                 
}

static void mdlOutputs(SimStruct *S, int_T tid)
{

#ifndef MATLAB_MEX_FILE

    uint_T i, n, channel;
    uint_T base_adc = ssGetIWorkValue(S, BASE_ADDR_I_IND);
    uint_T base_status = ssGetIWorkValue(S, BASE_ADDR_I_IND+1);
    real_T *y, range;
    short adParameters;
    short res;

	
    for (i=0;i<mxGetNumberOfElements(CHANNEL_ARG);i++) {
        channel=(uint_T)mxGetPr(CHANNEL_ARG)[i]-1;
        y=ssGetOutputPortSignal(S,i);
        range=mxGetPr(RANGE_ARG)[i];

        adParameters = 0x40;
        adParameters |= (channel & 0x07);
        if (range<0) adParameters |= 0x08;      /* bipolar range */
        if (abs(range)>5) adParameters |= 0x10; /* 10 V range */

        rl32eOutpB((unsigned short)(base_adc),adParameters);    /* start conversion */
        while (rl32eInpB((unsigned int)(base_status+0x10)) & 0x04);   /* wait until data ready */

        res=rl32eInpB((unsigned int)(base_adc))&0xff;       /* read data */
        res+=(rl32eInpB(base_adc+1)&0xff)<<8;       /* read data */
        if (range>0) {                          /* unipolar input */
            y[0]=(double)res*range/4096.; 
        } else {                                /* bipolar input */
            y[0]=-(double)res*range/2048.; 

        }
    }

#endif
        	        
}

static void mdlTerminate(SimStruct *S)
{   
}


#ifdef MATLAB_MEX_FILE  /* Is this file being compiled as a MEX-file? */
#include "simulink.c"   /* Mex glue */
#else
#include "cg_sfun.h"    /* Code generation glue */
#endif


