function [SampleTime, SampleOffset] = mdohsmf604 (flag, boardType, Channels, Sample, Slot)

% MDOHSMF614 - InitFcn and Mask Initialization for Humusoft MF614 digital output section

% Copyright (c) 2003 by Humusoft s.r.o.
% $Revision:  $ $Date:  $

% Initialize Data Values
persistent pool;

if flag == 0
  pool = [];
  return;
end

MAX_CHANNEL = 8;

switch boardType
  case 1
    chnDisplay='disp(''MF614\nHumusoft\n';
    description='MF614';
  case 2
    chnDisplay='disp(''AD612\nHumusoft\n';
    description='AD612';
end

% Get Length Channel Vector
chnLength = length(Channels);

% Label Input Ports

% Compose MaskDisplay String
chnDisplay=[chnDisplay,'Digital Output'');'];
for i = 1:chnLength
  chnDisplay = strcat(chnDisplay,'port_label(''input'', ');
  chnDisplay = strcat(chnDisplay,num2str(i));
  chnDisplay = strcat(chnDisplay,' , ''');
  chnDisplay = strcat(chnDisplay, num2str(Channels(1,i)));
  chnDisplay = strcat(chnDisplay, ''') ');
end

% Set MaskDisplay String
set_param(gcb,'MaskDisplay',chnDisplay);

% Check Parameters

% Check Channel Vector
% Check Parameters
for i=1:chnLength
   if (Channels(i)<1 | Channels(i)>MAX_CHANNEL)
      error(['The channel numbers must be in the range 1..',num2str(MAX_CHANNEL)]);
   end
end

for j = 1:(i-1)
  if Channels(i) == Channels(j)
    error ('Multiple entries of the same channel are not allowed')
  end
end

% Check sample time

sampleLength = length (Sample);

if (sampleLength > 2)
  error ('Sample length vector cannot exceed two elements');
end

if (sampleLength == 2)
  SampleTime = Sample(1);
  SampleOffset = Sample(2);
else
  SampleTime = Sample(1);
  SampleOffset = 0;
end

% Check For Multipule instances using the same channel

boardtype=['btype',num2str(boardType)];
if Slot<0
  boardref=['ref','a'];
else
  boardref=['ref',num2str(Slot)];
end
if ~isfield(pool,boardtype)
  eval(['pool.',boardtype,'=[];']);
end
level1=getfield(pool,boardtype);
if ~isfield(level1,boardref)
  eval(['level1.',boardref,'.Used=0;']);
end
level2=getfield(level1,boardref);
if level2.Used==1
  error('Only one block per physical board supported (hardware limitation)');
end
level2.Used=1;
level1=setfield(level1,boardref,level2);
pool=setfield(pool,boardtype,level1);
% EOF mdohsmf614.m
