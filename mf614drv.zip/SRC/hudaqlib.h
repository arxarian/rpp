#include <windef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
  unsigned short base;
  unsigned short length;
} BOARDIOADDRESS;

int WINAPI GetBoardIOAddress(const char* devicename, int deviceorder, int ioaddrsize, BOARDIOADDRESS* ioaddr, int* ioaddravail);


#ifdef __cplusplus
}
#endif
