#include <windows.h>
#include <stdio.h>
#include <hudaqlib.h>



extern "C" void __cdecl main(void)
{
BOARDIOADDRESS ioaddr[3];

if (!GetBoardIOAddress("MF614", 1, 3, ioaddr, NULL))
{
  printf("Board not found.\n");
  return;
}
else
{
  for (int i=0; i<3; i++)
    printf("I/O %d: base %04X, length %d.\n", i, ioaddr[i].base, ioaddr[i].length);
}

}
